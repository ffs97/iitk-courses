
################################## ESO Assignment 2 ###########################################


Gurpreet Singh (150259) - Batch G7


- The sample outputs for all the methods are provided in the Output Samples Folder.
- The program files are in the Program Files folder.
- To run the program, copy the input matrix file into the Program Files folder and run the file main.m
	- The code will prompt you for the name of the input matrix file, in this case it is 'input matrix.txt'
	- The outputs will be generated in the same place where the main.m file is located.